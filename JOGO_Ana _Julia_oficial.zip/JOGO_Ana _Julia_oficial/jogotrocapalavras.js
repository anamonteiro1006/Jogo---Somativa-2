//alert("linkouu😁")

function TrocaPalavra(){
    palavraDigitada = document.getElementById("palavra").value

    document.getElementById("palavra_1").innerHTML = palavraDigitada
    document.getElementById("palavra_2").innerHTML = palavraDigitada
    document.getElementById("palavra_3").innerHTML = palavraDigitada
    document.getElementById("palavra_4").innerHTML = palavraDigitada
    document.getElementById("palavra_5").innerHTML = palavraDigitada
    document.getElementById("palavra_6").innerHTML = palavraDigitada
    
    //alert(palavraDigitada)
}




